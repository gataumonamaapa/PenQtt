import nmap

def detect_mqtt_port_nmap(broker_ip, timeout=5):
    nm = nmap.PortScanner()
    try:
        # Pindai dua port standar MQTT
        nm.scan(broker_ip, arguments=f'-p 1883,8883 --host-timeout {timeout}s')

        # Cek status port
        if nm.all_hosts():
            ports = nm[broker_ip]['tcp']
            if 1883 in ports and ports[1883]['state'] == 'open':
                return 1883, False
            elif 8883 in ports and ports[8883]['state'] == 'open':
                return 8883, True

    except Exception as e:
        print(f"[!] Gagal melakukan scan Nmap: {e}")
    return None, None
